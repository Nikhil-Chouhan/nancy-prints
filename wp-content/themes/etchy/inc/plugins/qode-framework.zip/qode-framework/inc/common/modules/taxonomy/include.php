<?php

require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/taxonomy/core/options.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/taxonomy/core/page.php';