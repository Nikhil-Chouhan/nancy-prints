<?php

interface iQodeFrameworkChildInterface {
	public function get_name();
}