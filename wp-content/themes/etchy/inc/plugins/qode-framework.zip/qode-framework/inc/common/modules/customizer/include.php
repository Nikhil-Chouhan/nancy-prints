<?php

require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/customizer/core/options.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/customizer/core/page.php';