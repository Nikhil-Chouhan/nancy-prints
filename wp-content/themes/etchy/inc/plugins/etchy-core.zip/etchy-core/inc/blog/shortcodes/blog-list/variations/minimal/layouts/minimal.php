<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php etchy_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/title', '', $params ); ?>
	</div>
</article>