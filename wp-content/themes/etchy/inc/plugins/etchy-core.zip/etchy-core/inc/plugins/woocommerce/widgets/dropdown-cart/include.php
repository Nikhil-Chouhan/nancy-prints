<?php

include_once ETCHY_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/dropdown-cart.php';