<?php

include_once ETCHY_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/variations/info-bottom-left/info-bottom-left.php';