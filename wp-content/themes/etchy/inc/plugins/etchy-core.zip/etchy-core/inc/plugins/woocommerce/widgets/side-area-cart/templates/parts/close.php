<a class="qodef-m-close" href="#">
	<span class="qodef-m-close-icon"><?php echo qode_framework_icons()->get_specific_icon_from_pack( 'close', 'elegant-icons' ); ?></span>
</a>