(function ($) {
    "use strict";

    qodefCore.shortcodes.etchy_core_clients_list = {};
    qodefCore.shortcodes.etchy_core_clients_list.qodefSwiper = qodef.qodefSwiper;
})(jQuery);