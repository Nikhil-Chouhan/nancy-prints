<?php

include_once ETCHY_CORE_INC_PATH . '/opener-icon/helper.php';