<?php

include_once ETCHY_CORE_PLUGINS_PATH . '/woocommerce/widgets/taxonomy-items/taxonomy-items.php';