<?php

include_once ETCHY_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/helper.php';
include_once ETCHY_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/yith-wishlist.php';