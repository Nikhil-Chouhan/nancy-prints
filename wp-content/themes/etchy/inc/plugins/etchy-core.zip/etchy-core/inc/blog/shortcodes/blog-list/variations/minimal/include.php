<?php

include_once ETCHY_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/minimal/minimal.php';