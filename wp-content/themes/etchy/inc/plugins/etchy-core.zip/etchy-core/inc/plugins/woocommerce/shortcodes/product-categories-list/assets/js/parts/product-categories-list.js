(function ($) {
    "use strict";
    
	qodefCore.shortcodes.etchy_core_product_categories_list = {};
	qodefCore.shortcodes.etchy_core_product_categories_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.etchy_core_product_categories_list.qodefSwiper = qodef.qodefSwiper;

})(jQuery);