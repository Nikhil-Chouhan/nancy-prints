<?php

include_once ETCHY_CORE_INC_PATH . '/icons/simple-line-icons/simple-line-icons.php';