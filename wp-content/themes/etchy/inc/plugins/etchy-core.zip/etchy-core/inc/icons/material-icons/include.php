<?php

include_once ETCHY_CORE_INC_PATH . '/icons/material-icons/material-icons.php';