<?php

include_once ETCHY_CORE_PLUGINS_PATH . '/wpbakery/helper.php';