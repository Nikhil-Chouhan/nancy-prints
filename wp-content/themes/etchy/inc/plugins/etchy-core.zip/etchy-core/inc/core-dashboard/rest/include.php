<?php

include_once ETCHY_CORE_INC_PATH . '/core-dashboard/rest/rest.php';