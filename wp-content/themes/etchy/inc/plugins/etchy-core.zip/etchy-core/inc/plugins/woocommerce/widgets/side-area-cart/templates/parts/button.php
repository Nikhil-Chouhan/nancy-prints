<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="qodef-m-checkout-link"><?php esc_html_e( 'Checkout', 'etchy-core' ); ?></a>
	<a itemprop="url" href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="qodef-m-cart-link"><?php esc_html_e( 'View Cart', 'etchy-core' ); ?></a>
</div>