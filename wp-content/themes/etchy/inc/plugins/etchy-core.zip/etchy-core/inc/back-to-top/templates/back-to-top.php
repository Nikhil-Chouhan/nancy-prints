<a id="qodef-back-to-top" href="#" class="qodef-button qodef-btn-wave-hover qodef-type--filled">
    <span class="qodef-back-to-top-icon">
		<?php echo qode_framework_icons()->get_specific_icon_from_pack( 'back-to-top', 'linea-icons' ); ?>
    </span>
	<!--<span class="qodef-btn-masked">
	</span>-->
</a>